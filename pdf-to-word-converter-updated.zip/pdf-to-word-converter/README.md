# Convertly | PDF to Word Converter

A responsive web app that turns text-based PDF documents into editable Microsoft Word (`.docx`) files. Built with **Python, Flask, pdf2docx, HTML, CSS, and JavaScript**.

Convertly provides drag-and-drop uploading, clear error messages, and an automatic DOCX download. No account is needed.

> **Please note:** This is an educational portfolio project. It works best on PDFs containing selectable text. Scanned documents require OCR, which is not supported in this version. Complex page layouts may not convert perfectly.

## Features

- Drag and drop a PDF or browse for a file
- Convert a text-based PDF into an editable `.docx` file
- Automatically download the converted file
- Responsive interface for desktop and mobile
- Client-side and server-side file validation
- 15 MB file-size limit and 75-page limit
- Reject invalid or password-protected PDFs
- Delete temporary files after processing
- Automated API tests and GitHub Actions workflow

## Built with

- **Python** and **Flask** for the web server and API
- **pdf2docx** for PDF-to-DOCX conversion
- **PyMuPDF** for validating and inspecting PDFs
- **HTML, CSS, and JavaScript** for the interface
- **pytest** for automated tests

## Run in VS Code (Windows)

### 1. Download the code

On this repository's GitHub page, click **Code → Download ZIP**. Extract the ZIP, then open the `pdf-to-word-converter` folder in **Visual Studio Code** (**File → Open Folder**).

Alternatively, use **Code → HTTPS** to copy the repository URL and run `git clone` with that copied URL in your terminal.

### 2. Install Python

Install **Python 3.11** if it is not already installed. During setup, enable **Add Python to PATH** if offered.

In VS Code, choose **Terminal → New Terminal**. The terminal should be open in the project directory.

Verify Python is available:

```powershell
py -3.11 --version
```

### 3. Create a virtual environment

```powershell
py -3.11 -m venv .venv
```

If you installed another supported Python version and the command above fails, use `py -m venv .venv` instead.

### 4. Install required packages

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

You don't need to activate the environment when using this command.

### 5. Start the app

```powershell
.\.venv\Scripts\python.exe app.py
```

Open **http://127.0.0.1:5000** in your web browser.

To stop the server, press **Ctrl+C** in the VS Code terminal.

## Run on macOS or Linux

Open the project folder in VS Code, then run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000**. Stop the server with **Ctrl+C**.

## How to use

1. Open Convertly in your browser.
2. Drag a `.pdf` file into the upload area, or click to select one.
3. Click **Convert to Word**.
4. When conversion finishes, your `.docx` file downloads automatically.
5. Open the downloaded file in Microsoft Word or another DOCX editor.

For the best results, try a small PDF with selectable text first.

## Project structure

```text
pdf-to-word-converter/
├── .github/
│   └── workflows/
│       └── tests.yml
├── static/
│   ├── app.js
│   └── style.css
├── templates/
│   └── index.html
├── tests/
│   └── test_app.py
├── .gitignore
├── app.py
├── requirements.txt
├── requirements-dev.txt
├── LICENSE
└── README.md
```

## Run the tests in VS Code

After installing the main dependencies, install the test dependencies and run pytest.

**Windows (PowerShell):**

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
```

**macOS / Linux (with the virtual environment activated):**

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

The automated tests cover the home page, health endpoint, invalid uploads, and a simulated DOCX download. **The DOCX download test mocks the conversion engine**, so also test a real PDF manually before deployment.

## API

- `GET /` serves the user interface.
- `GET /health` responds with `{"status":"ok"}`.
- `POST /api/convert` accepts a PDF in the `file` field and returns a `.docx` download on success.

Example request while the local server is running:

```bash
curl -X POST -F "file=@example.pdf" http://127.0.0.1:5000/api/convert -o example.docx
```

Replace `example.pdf` with a PDF file on your computer.

## Known limitations and privacy

- Text-based PDFs convert more reliably than complex PDFs.
- Scanned PDFs and photos of documents need OCR and are not supported.
- Font styles, images, tables, and page breaks may change in the output.
- Maximum accepted upload: **15 MB**; maximum PDF length: **75 pages**.
- The app removes its temporary input and output files after each request, but a public hosting provider may retain logs or other data.
- `pdf2docx` is no longer actively maintained by its original maintainer. Evaluate dependencies before using this project in production.
- This demo is not hardened for a public, untrusted upload service. Production hosting requires further security measures, including resource isolation, rate limiting, and HTTPS.
- The Flask development server is for local testing only. **GitHub Pages cannot host this Flask application** because it does not run Python backends.

## Contributing

Suggestions and pull requests are welcome. Please open an issue to discuss a major change before submitting it.

## License

Distributed under the [MIT License](LICENSE).
