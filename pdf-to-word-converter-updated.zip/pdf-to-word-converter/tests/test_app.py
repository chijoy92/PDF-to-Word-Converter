import io
from unittest.mock import patch

import fitz
import pytest
from docx import Document

from app import create_app


@pytest.fixture
def client():
    app = create_app({"TESTING": True})
    return app.test_client()


def valid_pdf():
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Hello from this PDF")
    result = doc.tobytes()
    doc.close()
    return result


def test_home(client):
    assert client.get("/").status_code == 200


def test_health(client):
    assert client.get("/health").json == {"status": "ok"}


def test_missing_file(client):
    response = client.post("/api/convert", data={})
    assert response.status_code == 400


def test_wrong_extension(client):
    response = client.post("/api/convert", data={"file": (io.BytesIO(b"not a pdf"), "bad.txt")})
    assert response.status_code == 400


def test_invalid_pdf(client):
    response = client.post("/api/convert", data={"file": (io.BytesIO(b"%PDF-bogus"), "bad.pdf")})
    assert response.status_code == 400


def test_conversion_download(client):
    def mock_convert(_source, target):
        doc = Document()
        doc.add_paragraph("Hello from this PDF")
        doc.save(target)

    with patch("app.convert_pdf", side_effect=mock_convert):
        response = client.post("/api/convert", data={"file": (io.BytesIO(valid_pdf()), "example.pdf")})
        assert response.status_code == 200
        assert response.data[:2] == b"PK"
        assert "example.docx" in response.headers["Content-Disposition"]
