"""PDF to Word web converter. Files are processed in temporary storage."""
from __future__ import annotations

import os
from io import BytesIO
import tempfile
from pathlib import Path

import fitz
from flask import Flask, jsonify, render_template, request, send_file
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

MAX_FILE_MB = 15
MAX_PAGES = 75


def convert_pdf(source: Path, destination: Path) -> None:
    """Convert using pdf2docx, loaded only when conversion is requested."""
    from pdf2docx import Converter

    converter = Converter(str(source))
    try:
        converter.convert(str(destination), start=0, end=None)
    finally:
        converter.close()


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(MAX_CONTENT_LENGTH=MAX_FILE_MB * 1024 * 1024)
    if test_config:
        app.config.update(test_config)

    @app.get("/")
    def index():
        return render_template("index.html", max_size=MAX_FILE_MB)

    @app.get("/health")
    def health():
        return jsonify(status="ok")

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_error):
        return jsonify(error=f"File is too large. Maximum size is {MAX_FILE_MB} MB."), 413

    @app.post("/api/convert")
    def convert():
        upload = request.files.get("file")
        if upload is None or not upload.filename:
            return jsonify(error="Choose a PDF file first."), 400

        original_name = secure_filename(upload.filename)
        if not original_name.lower().endswith(".pdf"):
            return jsonify(error="Only .pdf files are supported."), 400

        work = tempfile.TemporaryDirectory(prefix="pdf2word_")
        work_path = Path(work.name)
        source = work_path / "input.pdf"
        destination = work_path / "output.docx"
        try:
            upload.save(source)
            if source.stat().st_size == 0:
                return jsonify(error="The uploaded PDF is empty."), 400
            with source.open("rb") as pdf_file:
                if pdf_file.read(5) != b"%PDF-":
                    return jsonify(error="This does not appear to be a valid PDF."), 400
            try:
                with fitz.open(source) as document:
                    if document.needs_pass:
                        return jsonify(error="Password-protected PDFs are not supported."), 400
                    if document.page_count == 0:
                        return jsonify(error="This PDF has no pages."), 400
                    if document.page_count > MAX_PAGES:
                        return jsonify(error=f"PDFs must contain {MAX_PAGES} pages or fewer."), 400
            except (fitz.FileDataError, fitz.EmptyFileError, ValueError):
                return jsonify(error="The PDF is damaged or could not be read."), 400

            try:
                convert_pdf(source, destination)
                if not destination.is_file() or destination.stat().st_size == 0:
                    raise RuntimeError("Converter did not produce a Word file")
            except Exception:
                app.logger.exception("PDF conversion failed")
                return jsonify(error="Conversion failed. Try a different text-based PDF."), 422

            download_name = f"{Path(original_name).stem or 'converted'}.docx"
            # Read result before closing the temporary directory. No user files
            # are permanently stored by the application.
            content = destination.read_bytes()
            return send_file(
                BytesIO(content),
                as_attachment=True,
                download_name=download_name,
                mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )
        finally:
            work.cleanup()

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG") == "1")
