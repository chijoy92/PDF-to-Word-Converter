'use strict';
const input = document.getElementById('file-input');
const zone = document.getElementById('drop-zone');
const form = document.getElementById('convert-form');
const selected = document.getElementById('file-selected');
const remove = document.getElementById('remove-file');
const button = document.getElementById('convert-btn');
const feedback = document.getElementById('feedback');
const spinner = document.getElementById('spinner');
const btnText = document.getElementById('btn-text');
const btnArrow = document.getElementById('btn-arrow');
const MAX_BYTES = 15 * 1024 * 1024;
let file = null;
let busy = false;

function showMessage(message, isError = false) {
  feedback.textContent = message;
  feedback.classList.remove('hidden');
  feedback.classList.toggle('error', isError);
}
function clearMessage() { feedback.classList.add('hidden'); feedback.textContent = ''; }
function chooseFile(next) {
  if (busy) return;
  clearMessage();
  if (!next) return;
  if (!next.name.toLowerCase().endsWith('.pdf') || (next.type && next.type !== 'application/pdf')) {
    showMessage('Please choose a PDF document.', true); return;
  }
  if (next.size > MAX_BYTES) { showMessage('PDF must be 15 MB or less.', true); return; }
  if (next.size === 0) { showMessage('This file is empty.', true); return; }
  file = next;
  document.getElementById('file-name').textContent = next.name;
  document.getElementById('file-size').textContent = (next.size / 1048576).toFixed(2) + ' MB';
  selected.classList.remove('hidden');
  button.disabled = false;
}
zone.addEventListener('click', () => { if (!busy) input.click(); });
zone.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); if (!busy) input.click(); } });
input.addEventListener('change', () => chooseFile(input.files[0]));
for (const eventName of ['dragenter', 'dragover']) zone.addEventListener(eventName, event => { event.preventDefault(); zone.classList.add('dragover'); });
for (const eventName of ['dragleave', 'drop']) zone.addEventListener(eventName, event => { event.preventDefault(); zone.classList.remove('dragover'); });
zone.addEventListener('drop', event => chooseFile(event.dataTransfer.files[0]));
remove.addEventListener('click', () => { if (busy) return; file = null; input.value = ''; selected.classList.add('hidden'); button.disabled = true; clearMessage(); });
form.addEventListener('submit', async event => {
  event.preventDefault();
  if (!file || busy) return;
  busy = true; button.disabled = true; spinner.classList.remove('hidden'); btnArrow.classList.add('hidden'); btnText.textContent = 'Converting your PDF...'; clearMessage();
  const body = new FormData(); body.append('file', file);
  try {
    const response = await fetch('/api/convert', { method: 'POST', body });
    if (!response.ok) {
      let message = 'Something went wrong. Please try again.';
      try { const data = await response.json(); message = data.error || message; } catch (_) { /* non-JSON server response */ }
      throw new Error(message);
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url;
    link.download = file.name.replace(/\.pdf$/i, '') + '.docx';
    document.body.appendChild(link); link.click(); link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60000);
    showMessage('Success! Your Word document is downloading.');
  } catch (error) { showMessage(error.message || 'Conversion failed.', true); }
  finally { busy = false; button.disabled = !file; spinner.classList.add('hidden'); btnArrow.classList.remove('hidden'); btnText.textContent = 'Convert to Word'; }
});
